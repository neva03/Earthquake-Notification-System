public class Earthquake {
    private String id;
    private int time;
    private String place;
    private String coordinates;
    private double magnitude;

    public Earthquake(){
        
    }
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the time
     */
    public int getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(int time) {
        this.time = time;
    }

    /**
     * @return the place
     */
    public String getPlace() {
        return place;
    }

    /**
     * @param place the place to set
     */
    public void setPlace(String place) {
        this.place = place;
    }

    /**
     * @return the coordinates
     */
    public String getCoordinates() {
        return coordinates;
    }

    /**
     * @param coordinates the coordinates to set
     */
    public void setCoordinates(String coordinates) {
        this.coordinates = coordinates;
    }

    /**
     * @return the magnitude
     */
    public double getMagnitude() {
        return magnitude;
    }

    /**
     * @param magnitude the magnitude to set
     */
    public void setMagnitude(double magnitude) {
        this.magnitude = magnitude;
    }
    
    @Override
    public String toString(){
        return "Earthquake "+place+"is inserted into the earthquake-list";
    }
    
    public boolean isClose(Watcher w){
        String[] split = getCoordinates().split(",");
        double e_latitude=Double.parseDouble(split[0]);
        double e_longitude=Double.parseDouble(split[1]);
        
        double distance =((w.getLatitude()-e_latitude)*(w.getLatitude()-e_latitude))+ ((w.getLongitude()-e_longitude)*(w.getLongitude()-e_longitude));
        distance=Math.sqrt(distance);
        if(distance<(2*(getMagnitude()*getMagnitude()*getMagnitude())))
            return true;
        else
            return false;
    }

}
