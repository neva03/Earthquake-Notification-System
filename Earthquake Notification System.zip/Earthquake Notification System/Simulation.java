import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
//author Neva Aydın
public class Simulation {

    public static void main(String[] args) throws FileNotFoundException {
        String fileName;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter watcher file's pathname: ");
        fileName=scanner.nextLine();
        System.out.println("Enter earthquake file's pathname: ");
        String fileName2 =scanner.nextLine();

        Scanner watcherScanner = new Scanner(new File(fileName));
        Scanner earthquakeScanner = new Scanner(new File(fileName2));

        Object[] array = new Object[10];  //this will store Earthquake Object, Watcher Object, and String(query largest, or name that should be deleted)            

        while (watcherScanner.hasNextLine()) { // reads the watcherFile
            String row = watcherScanner.nextLine();
            String[] parts = row.split(" ");
            int time = Integer.parseInt(parts[0]);
            String method = parts[1];
            if (method.equals("add")) {
                double latitude = Double.parseDouble(parts[2]);
                double longitude = Double.parseDouble(parts[3]);
                String name = parts[4];
                Watcher newWatcher = new Watcher(time, method, latitude, longitude, name);
                if (time < array.length) {
                    array[time] = newWatcher;
                } else {
                    Object[] newArray = new Object[array.length * 2];
                    System.arraycopy(array, 0, newArray, 0, array.length);
                    array = newArray;
                    array[time] = newWatcher;
                }

            } else if (method.equals("query-largest")) {
                if (time < array.length) {
                    array[time] = "query-largest";
                } else {
                    Object[] newArray = new Object[array.length * 2];
                    System.arraycopy(array, 0, newArray, 0, array.length);
                    array = newArray;
                    array[time] = "query-largest";
                }

            } else if (method.equals("delete")) {
                String name = parts[2];
                if (time < array.length) {
                    array[time] = name;
                } else {
                    Object[] newArray = new Object[array.length * 2];
                    System.arraycopy(array, 0, newArray, 0, array.length);
                    array = newArray;
                    array[time] = name;
                }
            }
        }

        StringBuilder sB = new StringBuilder();
        String string = new String();
        while (earthquakeScanner.hasNextLine()) {
            sB.append(earthquakeScanner.nextLine());
            string = sB.toString();
        }
        String[] earthquakeSplit = string.split("<earthquake>");
        for (int i = 1; i < earthquakeSplit.length; i++) {

            Earthquake earthquake = new Earthquake();
            String input = (earthquakeSplit[i]);
            ArrayList<String> data = new ArrayList<>(); //to temporarily store earthquake file's info (id,time,place,coordinates,magnitude)

            int subStringStart = 0;
            char[] chars = {' ', '/'};
            int charIndex = 0;
            for (int j = 0; j < input.length(); j++) {

                if (input.charAt(j) == chars[charIndex]) {

                    if (chars[charIndex] == ' ') {
                        subStringStart = j;
                        charIndex++;
                    } else {
                        String subString = input.substring(subStringStart + 1, j - 2);
                        data.add(subString);
                        charIndex--;
                    }
                }
            }

            earthquake.setId(data.get(0));
            earthquake.setTime(Integer.parseInt(data.get(1)));
            earthquake.setPlace(data.get(2));
            earthquake.setCoordinates(data.get(3));
            earthquake.setMagnitude(Double.parseDouble(data.get(4)));

            if (earthquake.getTime() < array.length) {
                if (array[earthquake.getTime()] == null) {
                    array[earthquake.getTime()] = earthquake;
                } else {
                    array[earthquake.getTime() + 1] = earthquake;
                }
            } else {
                Object[] newArray = new Object[array.length * 2];
                System.arraycopy(array, 0, newArray, 0, array.length);
                array = newArray;
                array[earthquake.getTime()] = earthquake;
            }
        }
        DoublyLinkedList<Watcher> watcherList = new DoublyLinkedList<>();
        DoublyLinkedList<Earthquake> earthquakeList = new DoublyLinkedList<>();

        int hour = 0;
        for (Object i : array) {
            for (int k = 0; k < earthquakeList.size(); k++) { //to make earthquakelist, last 6 hours
                if (hour - (earthquakeList.getElement(k).getTime()) > 6) {
                    earthquakeList.remove(k);
                }
            }
            if (i instanceof Watcher) { //if i is object of a Watcher
                Watcher watcher = (Watcher) i;
                watcherList.addLast(watcher);
                System.out.println(watcher.getName() + " is added to the watcher-list");
                System.out.println();
            } else if (i instanceof Earthquake) { //if i is object of a Earthquake
                Earthquake earthquake = (Earthquake) i;
                earthquakeList.addLast(earthquake);
                System.out.println("Earthquake " + earthquake.getPlace() + "is inserted into the earthquake-list");
                for (int h = 0; h < watcherList.size(); h++) {
                    if (earthquake.isClose(watcherList.getElement(h))) {
                        System.out.println("Earthquake " + earthquake.getPlace() + " is close to " + watcherList.getElement(h).getName());
                    }
                }
                System.out.println();
            } else if (i == null) { //if i is empty, then do nothing 
                
            } else { //if i is query largest or delete 
                String s = (String) i;
                if (s.equals("query-largest")) { //finds largest earthquake in last 6 hours
                    if (earthquakeList.size() == 0) {
                        System.out.println("No record on list");
                        System.out.println();
                    } else { 
                        double largest = earthquakeList.first().getMagnitude();
                        String place = earthquakeList.first().getPlace();
                        for (int k = 0; k < earthquakeList.size(); k++) {                            
                            if(earthquakeList.getElement(k).getMagnitude()>largest){
                                largest = earthquakeList.getElement(k).getMagnitude();
                                place = earthquakeList.getElement(k).getPlace();
                            }
                        }
                        System.out.println("Largest earthquake in the past 6 hours:");
                        System.out.println("Magnitude " + largest + " at " + place);
                        System.out.println();
                    }

                } else { //deletes the name from the watcherList
                    for (int n = 0; n < watcherList.size(); n++) {                        
                        if (watcherList.getElement(n).getName().equals(s)) {
                            watcherList.remove(n);
                            System.out.println(s + " is removed from the watcher-list");
                            break;
                        }
                    }
                    System.out.println();
                }
            }
            hour++;
        }
    }
}